# HIST-LONG-4 — Real Multi-Window Ecology Accumulation Review

## Window-Level Results
| Window | Normalized rows | Completeness | Partial | Failed | Exact ratio | Reconciled ratio | Weak symbols |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20 | 4820 | 1.0 | 0 | 0 | 0.95 | 0.05 | none |
| 60 | 14460 | 1.0 | 0 | 0 | 0.966667 | 0.033333 | none |
| 120 | 28920 | 1.0 | 0 | 0 | 0.95 | 0.05 | none |

### Parsed Artifact Bundles
- 20d: bundle=`artifacts/hist_long4_window_020d_completed_bundle.zip`, parsed={"chunk_manifest_count": 5, "hist_density3_config_preview_present": true, "hist_density3_summary_present": true, "ops_hist_snapshot_count": 100, "telemetry_summary_count": 5}
- 60d: bundle=`artifacts/hist_long4_window_060d_completed_bundle.zip`, parsed={"chunk_manifest_count": 5, "hist_density3_config_preview_present": true, "hist_density3_summary_present": true, "ops_hist_snapshot_count": 300, "telemetry_summary_count": 5}
- 120d: bundle=`artifacts/hist_long4_window_120d_completed_bundle.zip`, parsed={"chunk_manifest_count": 5, "hist_density3_config_preview_present": true, "hist_density3_summary_present": true, "ops_hist_snapshot_count": 600, "telemetry_summary_count": 5}

## Longitudinal Comparison
| Window | Normalized | Completeness | Weak symbols |
| --- | --- | --- | --- |
| 20 | 4820 | 1.0 | none |
| 60 | 14460 | 1.0 | none |
| 120 | 28920 | 1.0 | none |
- Ingestion quality: `{"completeness": {"trend": "stable", "values": [1.0, 1.0, 1.0], "volatility": 0.0}, "endpoint_failure_window_count": 0, "exact_date_match_ratios": {"trend": "stable", "values": [0.95, 0.966667, 0.95]}, "failed_counts": [0, 0, 0], "normalized_rows": {"trend": "increasing", "values": [4820, 14460, 28920]}, "partial_counts": [0, 0, 0], "reconciled_date_ratios": {"trend": "stable", "values": [0.05, 0.033333, 0.05]}}`
- Ecology stability: `{"contradiction_burden": {"trend": "stable", "values": [0.0, 0.0, 0.0], "volatility": 0.0}, "morphology_persistence": {"assessment": "stable_across_completed_real_windows", "posture_recurrence": [{"posture": "stable_single_posture", "window_count": 3}]}, "replay_density": {"activation_status": "not_activated", "trend": "stable", "values": [1.0, 1.0, 1.0]}, "replay_saturation": "not_activated_density_only", "temporal_persistence": "multi_window_comparison_available", "topology_richness": {"persistence_status": "report_local_not_persisted", "trend": "stable", "values": [2.0, 2.0, 2.0]}}`

## Weak Symbol Recurrence
- Recurring weak symbols: `[]`
- New weak symbols: `[]`
- FOXA stability: `{"assessment": "stable_not_weak", "present_all_windows": true, "weak_windows": []}`

## Provider Degradation Trends
- Provider degradation recurrence: `[]`

## Replay Ecology Persistence
- Replay persistence trend: stable
- Replay density: `{"activation_status": "not_activated", "trend": "stable", "values": [1.0, 1.0, 1.0]}`
- Morphology persistence: `{"assessment": "stable_across_completed_real_windows", "posture_recurrence": [{"posture": "stable_single_posture", "window_count": 3}]}`

## Concentration Drift
- Concentration trend: stable
- Sector HHI: `{"trend": "stable", "values": [0.06107, 0.06107, 0.06107]}`
- Subsector HHI: `{"trend": "stable", "values": [0.06107, 0.06107, 0.06107]}`
- Strongest recurring sectors: `[{"sector": "cloud_software_infrastructure", "window_count": 3}, {"sector": "commodities", "window_count": 3}, {"sector": "consumer_discretionary", "window_count": 3}, {"sector": "energy_utilities", "window_count": 3}, {"sector": "financials", "window_count": 3}, {"sector": "healthcare_biotech", "window_count": 3}, {"sector": "industrials_automation", "window_count": 3}, {"sector": "semiconductors", "window_count": 3}]`
- Strongest recurring subsectors: `[{"subsector": "cloud_software_infrastructure", "window_count": 3}, {"subsector": "commodities", "window_count": 3}, {"subsector": "consumer_discretionary", "window_count": 3}, {"subsector": "energy_utilities", "window_count": 3}, {"subsector": "financials", "window_count": 3}, {"subsector": "healthcare_biotech", "window_count": 3}, {"subsector": "industrials_automation", "window_count": 3}, {"subsector": "semiconductors", "window_count": 3}]`

## Structural Stability
- Stable structures: `["five_chunk_envelope", "curated_241_symbol_universe", "observational_governance", "stable_single_posture"]`
- Decaying structures: `[]`
- Emerging structures: `[]`
- Propagation asymmetry: provider_degradation_not_recurring

## Fragility Emergence
- Fragility clusters: `["none_detected"]`

## Operational Stability Assessment
- real_multi_window_status: `all_required_windows_completed`
- five_chunk_envelope: `stable`
- provider_degradation_trend: `[]`
- foxa_assessment: `{"assessment": "stable_not_weak", "present_all_windows": true, "weak_windows": []}`
- governance_boundary: `observational_only_no_replay_no_supabase_no_raw_cache_write_no_topology_persistence`

## Governance Certification
- Governance mode: observational_only
- Prediction enabled: False
- Trading execution enabled: False
- Replay activation enabled: False
- Replay execution enabled: False
- Topology persistence enabled: False
- Supabase writes enabled: False
- Raw cache writes enabled: False
- Local artifacts only: True

## Recommendation For HIST-LONG-5
- Proceed to HIST-LONG-5 with the same observational-only guards if operator accepts stable replay persistence and concentration drift findings; keep replay inactive and topology non-persistent.
